export const baseUrl = "http://localhost:5050/api/chithi-diyo";
